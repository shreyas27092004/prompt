// Only endpoints that exist in backend/openapi.yaml are called here (no invented APIs).
const BASE = '/api/v1';

export class ApiFailure extends Error {
  constructor(status, body) {
    super(body?.message || `Request failed (${status})`);
    this.status = status;
    this.code = body?.code;
    this.details = body?.details || [];
  }
}

async function request(path, { method = 'GET', token, body, signal } = {}) {
  const res = await fetch(BASE + path, {
    method,
    signal,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) throw new ApiFailure(res.status, data);
  return data;
}

export const api = {
  listProducts: (signal) => request('/products', { signal }),
  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),
  register: (email, password) => request('/users/register', { method: 'POST', body: { email, password } }),
  getCart: (token) => request('/cart', { token }),
  addToCart: (token, productId, quantity) => request('/cart/items', { method: 'POST', token, body: { productId, quantity } }),
  updateQuantity: (token, productId, quantity) => request(`/cart/items/${productId}`, { method: 'PATCH', token, body: { quantity } }),
  removeItem: (token, productId) => request(`/cart/items/${productId}`, { method: 'DELETE', token }),
  checkout: (token, body) => request('/orders', { method: 'POST', token, body }),
};

export const formatPrice = (paise) => `₹${(paise / 100).toLocaleString('en-IN', { minimumFractionDigits: 2 })}`;
