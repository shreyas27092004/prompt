import { useCallback, useState } from 'react';
import { api } from './api.js';
import ProductList from './components/ProductList.jsx';
import Cart from './components/Cart.jsx';
import CheckoutForm from './components/CheckoutForm.jsx';

const EMPTY_CART = { items: [], totalPaise: 0 };

export default function App() {
  const [token, setToken] = useState(null);
  const [cart, setCart] = useState(EMPTY_CART);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);
  const [credentials, setCredentials] = useState({ email: '', password: '' });

  // Every cart mutation goes through one function: shows server message on failure, never mutates state in place.
  const run = useCallback(async (action) => {
    setBusy(true);
    setMessage('');
    try {
      return await action();
    } catch (err) {
      setMessage(err.message);
      return null;
    } finally {
      setBusy(false);
    }
  }, []);

  async function login(e) {
    e.preventDefault();
    const result = await run(() => api.login(credentials.email, credentials.password));
    if (!result) return;
    setToken(result.token);
    const loaded = await run(() => api.getCart(result.token));
    if (loaded) setCart(loaded);
  }

  const add = async (product) => {
    const updated = await run(() => api.addToCart(token, product.id, 1));
    if (updated) setCart(updated);
  };
  const change = async (item, quantity) => {
    const updated = await run(() => api.updateQuantity(token, item.productId, quantity));
    if (updated) setCart(updated);
  };
  const remove = async (item) => {
    const updated = await run(() => api.removeItem(token, item.productId));
    if (updated) setCart(updated);
  };
  const checkout = async (body) => {
    const order = await run(() => api.checkout(token, body));
    if (order) {
      setCart(EMPTY_CART);
      setMessage(`Order placed. Total paid: ₹${(order.totalPaise / 100).toFixed(2)}`);
    }
  };

  return (
    <main>
      <h1>ShopSphere</h1>
      <div role="status" aria-live="polite">{message}</div>
      {!token ? (
        <form onSubmit={login} aria-labelledby="login-heading">
          <h2 id="login-heading">Log in</h2>
          <label htmlFor="email">Email</label>
          <input id="email" type="email" autoComplete="username" value={credentials.email} onChange={(e) => setCredentials({ ...credentials, email: e.target.value })} />
          <label htmlFor="password">Password</label>
          <input id="password" type="password" autoComplete="current-password" value={credentials.password} onChange={(e) => setCredentials({ ...credentials, password: e.target.value })} />
          <button type="submit" disabled={busy}>Log in</button>
        </form>
      ) : null}
      <ProductList onAdd={add} canAdd={Boolean(token) && !busy} />
      {token && (
        <>
          <Cart cart={cart} onChangeQuantity={change} onRemove={remove} busy={busy} />
          <CheckoutForm onSubmit={checkout} disabled={busy || cart.items.length === 0} />
        </>
      )}
    </main>
  );
}
