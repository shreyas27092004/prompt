// Demonstrates why the accessibility constraint must be in the prompt: a first-draft component without it FAILS axe.
import { render } from '@testing-library/react';
import { axe } from 'jest-axe';
import { expect, it } from 'vitest';

const BadDraft = () => (
  <div>
    <img src="/mouse.png" />
    <input placeholder="Search products" />
    <button><svg width="16" height="16" /></button>
    <div onClick={() => {}}>Add to cart</div>
  </div>
);

it('first-draft component (no a11y constraint in the prompt) has axe violations', async () => {
  const { container } = render(<BadDraft />);
  const results = await axe(container);
  console.log('AXE VIOLATIONS IN FIRST DRAFT:');
  for (const v of results.violations) console.log(` - ${v.id} (${v.impact}): ${v.help}`);
  expect(results.violations.length).toBeGreaterThan(0);
});
