import { formatPrice } from '../api.js';

export default function Cart({ cart, onChangeQuantity, onRemove, busy }) {
  return (
    <section aria-labelledby="cart-heading">
      <h2 id="cart-heading">Your cart</h2>
      {cart.items.length === 0 ? (
        <p>Your cart is empty.</p>
      ) : (
        <table>
          <caption className="sr-only">Items in your cart</caption>
          <thead>
            <tr><th scope="col">Item</th><th scope="col">Price</th><th scope="col">Quantity</th><th scope="col">Actions</th></tr>
          </thead>
          <tbody>
            {cart.items.map((item) => (
              <tr key={item.productId}>
                <th scope="row">{item.name}</th>
                <td>{formatPrice(item.unitPricePaise)}</td>
                <td>
                  <button type="button" disabled={busy || item.quantity <= 1} aria-label={`Decrease quantity of ${item.name}`} onClick={() => onChangeQuantity(item, item.quantity - 1)}>−</button>
                  <span aria-label={`Quantity of ${item.name}`}> {item.quantity} </span>
                  <button type="button" disabled={busy} aria-label={`Increase quantity of ${item.name}`} onClick={() => onChangeQuantity(item, item.quantity + 1)}>+</button>
                </td>
                <td><button type="button" disabled={busy} onClick={() => onRemove(item)} aria-label={`Remove ${item.name} from cart`}>Remove</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <p><strong>Total: {formatPrice(cart.totalPaise)}</strong></p>
    </section>
  );
}
