import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe } from 'jest-axe';
import { afterEach, describe, expect, it, vi } from 'vitest';
import ProductList from './ProductList.jsx';

const products = [
  { id: 'p1', name: 'Wireless Mouse', pricePaise: 79900, stock: 25, category: 'electronics' },
  { id: 'p2', name: 'Desk Lamp', pricePaise: 129900, stock: 0, category: 'home' },
];
const okResponse = (items) => ({ ok: true, status: 200, json: async () => ({ items, page: 1, size: 20, total: items.length }) });

afterEach(() => vi.restoreAllMocks());

describe('ProductList', () => {
  it('calls only the documented endpoint /api/v1/products', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch').mockResolvedValue(okResponse(products));
    render(<ProductList onAdd={() => {}} canAdd />);
    await screen.findByText('Wireless Mouse');
    expect(fetchMock.mock.calls[0][0]).toBe('/api/v1/products');
  });

  it('shows a loading status, then the products', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(okResponse(products));
    render(<ProductList onAdd={() => {}} canAdd />);
    expect(screen.getByRole('status')).toHaveTextContent('Loading products');
    expect(await screen.findByText('Wireless Mouse')).toBeInTheDocument();
    expect(screen.getByText('₹799.00')).toBeInTheDocument();
  });

  it('shows an empty state', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(okResponse([]));
    render(<ProductList onAdd={() => {}} canAdd />);
    expect(await screen.findByText('No products available.')).toBeInTheDocument();
  });

  it('shows an accessible error alert and retries', async () => {
    const fetchMock = vi.spyOn(globalThis, 'fetch')
      .mockResolvedValueOnce({ ok: false, status: 500, json: async () => ({ code: 'INTERNAL_ERROR', message: 'Unexpected error', details: [], traceId: 't' }) })
      .mockResolvedValueOnce(okResponse(products));
    render(<ProductList onAdd={() => {}} canAdd />);
    expect(await screen.findByRole('alert')).toHaveTextContent('Unexpected error');
    await userEvent.click(screen.getByRole('button', { name: 'Try again' }));
    expect(await screen.findByText('Wireless Mouse')).toBeInTheDocument();
    expect(fetchMock).toHaveBeenCalledTimes(2);
  });

  it('disables add-to-cart when logged out or out of stock, and exposes descriptive button names', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(okResponse(products));
    const { rerender } = render(<ProductList onAdd={() => {}} canAdd={false} />);
    expect(await screen.findByRole('button', { name: 'Add Wireless Mouse to cart' })).toBeDisabled();
    rerender(<ProductList onAdd={() => {}} canAdd />);
    expect(screen.getByRole('button', { name: 'Add Wireless Mouse to cart' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Add Desk Lamp to cart' })).toBeDisabled();
  });

  it('calls onAdd with the product', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValue(okResponse(products));
    const onAdd = vi.fn();
    render(<ProductList onAdd={onAdd} canAdd />);
    await userEvent.click(await screen.findByRole('button', { name: 'Add Wireless Mouse to cart' }));
    expect(onAdd).toHaveBeenCalledWith(products[0]);
  });

  it('aborts the in-flight request on unmount (race-condition guard)', async () => {
    let signal;
    vi.spyOn(globalThis, 'fetch').mockImplementation((_url, options) => {
      signal = options.signal;
      return new Promise(() => {});
    });
    const { unmount } = render(<ProductList onAdd={() => {}} canAdd />);
    unmount();
    expect(signal.aborted).toBe(true);
  });

  it('has no axe accessibility violations (ready and error states)', async () => {
    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce(okResponse(products));
    const ready = render(<ProductList onAdd={() => {}} canAdd />);
    await screen.findByText('Wireless Mouse');
    expect(await axe(ready.container)).toHaveNoViolations();
    ready.unmount();

    vi.spyOn(globalThis, 'fetch').mockResolvedValueOnce({ ok: false, status: 500, json: async () => ({ message: 'boom' }) });
    const failed = render(<ProductList onAdd={() => {}} canAdd />);
    await screen.findByRole('alert');
    expect(await axe(failed.container)).toHaveNoViolations();
  });
});
