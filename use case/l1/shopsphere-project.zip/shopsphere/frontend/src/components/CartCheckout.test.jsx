import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe } from 'jest-axe';
import { describe, expect, it, vi } from 'vitest';
import Cart from './Cart.jsx';
import CheckoutForm from './CheckoutForm.jsx';

const cart = { items: [{ productId: 'p1', name: 'Wireless Mouse', unitPricePaise: 79900, quantity: 2 }], totalPaise: 159800 };

describe('Cart', () => {
  it('renders items, total and descriptive controls', () => {
    render(<Cart cart={cart} onChangeQuantity={() => {}} onRemove={() => {}} busy={false} />);
    expect(screen.getByText('Total: ₹1,598.00')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Remove Wireless Mouse from cart' })).toBeInTheDocument();
  });

  it('shows the empty state', () => {
    render(<Cart cart={{ items: [], totalPaise: 0 }} onChangeQuantity={() => {}} onRemove={() => {}} busy={false} />);
    expect(screen.getByText('Your cart is empty.')).toBeInTheDocument();
  });

  it('sends the new quantity without mutating the cart prop', async () => {
    const frozen = Object.freeze({ items: Object.freeze([Object.freeze({ ...cart.items[0] })]), totalPaise: 159800 });
    const onChange = vi.fn();
    render(<Cart cart={frozen} onChangeQuantity={onChange} onRemove={() => {}} busy={false} />);
    await userEvent.click(screen.getByRole('button', { name: 'Increase quantity of Wireless Mouse' }));
    expect(onChange).toHaveBeenCalledWith(frozen.items[0], 3);
  });

  it('disables decrease at quantity 1 and everything while busy', () => {
    const one = { items: [{ ...cart.items[0], quantity: 1 }], totalPaise: 79900 };
    const { rerender } = render(<Cart cart={one} onChangeQuantity={() => {}} onRemove={() => {}} busy={false} />);
    expect(screen.getByRole('button', { name: 'Decrease quantity of Wireless Mouse' })).toBeDisabled();
    rerender(<Cart cart={cart} onChangeQuantity={() => {}} onRemove={() => {}} busy />);
    expect(screen.getByRole('button', { name: 'Remove Wireless Mouse from cart' })).toBeDisabled();
  });

  it('has no axe violations', async () => {
    const { container } = render(<Cart cart={cart} onChangeQuantity={() => {}} onRemove={() => {}} busy={false} />);
    expect(await axe(container)).toHaveNoViolations();
  });
});

describe('CheckoutForm', () => {
  it('shows an accessible validation error and does not submit when the token is empty', async () => {
    const onSubmit = vi.fn();
    render(<CheckoutForm onSubmit={onSubmit} disabled={false} />);
    await userEvent.click(screen.getByRole('button', { name: 'Place order' }));
    expect(screen.getByRole('alert')).toHaveTextContent('Enter a payment token');
    expect(screen.getByLabelText('Payment token')).toHaveAttribute('aria-invalid', 'true');
    expect(onSubmit).not.toHaveBeenCalled();
  });

  it('submits trimmed values; empty coupon becomes undefined', async () => {
    const onSubmit = vi.fn().mockResolvedValue();
    render(<CheckoutForm onSubmit={onSubmit} disabled={false} />);
    await userEvent.type(screen.getByLabelText('Payment token'), '  tok_ok ');
    await userEvent.click(screen.getByRole('button', { name: 'Place order' }));
    expect(onSubmit).toHaveBeenCalledWith({ paymentToken: 'tok_ok', couponCode: undefined });
  });

  it('prevents double submission while the first is in flight', async () => {
    let resolve;
    const onSubmit = vi.fn(() => new Promise((r) => { resolve = r; }));
    render(<CheckoutForm onSubmit={onSubmit} disabled={false} />);
    await userEvent.type(screen.getByLabelText('Payment token'), 'tok_ok');
    const button = screen.getByRole('button', { name: 'Place order' });
    await userEvent.click(button);
    expect(screen.getByRole('button', { name: 'Placing order…' })).toBeDisabled();
    await userEvent.type(screen.getByLabelText('Payment token'), '{Enter}');
    expect(onSubmit).toHaveBeenCalledTimes(1);
    resolve();
    await waitFor(() => expect(screen.getByRole('button', { name: 'Place order' })).toBeEnabled());
  });

  it('has no axe violations (clean and with error shown)', async () => {
    const { container } = render(<CheckoutForm onSubmit={() => {}} disabled={false} />);
    expect(await axe(container)).toHaveNoViolations();
    await userEvent.click(screen.getByRole('button', { name: 'Place order' }));
    expect(await axe(container)).toHaveNoViolations();
  });
});
