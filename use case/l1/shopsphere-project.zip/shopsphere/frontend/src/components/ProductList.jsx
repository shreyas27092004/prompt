import { useEffect, useState } from 'react';
import { api, formatPrice } from '../api.js';

export default function ProductList({ onAdd, canAdd }) {
  const [state, setState] = useState({ status: 'loading', products: [], error: null });
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    // AbortController prevents a slow, stale response from overwriting a newer one (race condition).
    const controller = new AbortController();
    api.listProducts(controller.signal)
      .then((page) => setState({ status: 'ready', products: page.items, error: null }))
      .catch((err) => {
        if (err.name === 'AbortError') return;
        setState({ status: 'error', products: [], error: err.message });
      });
    return () => controller.abort();
  }, [attempt]);

  const retry = () => {
    setState((prev) => ({ ...prev, status: 'loading' }));
    setAttempt((n) => n + 1);
  };

  return (
    <section aria-labelledby="products-heading">
      <h2 id="products-heading">Products</h2>
      <div role="status" aria-live="polite">
        {state.status === 'loading' && 'Loading products…'}
        {state.status === 'ready' && state.products.length === 0 && 'No products available.'}
      </div>
      {state.status === 'error' && (
        <div role="alert">
          <p>Could not load products: {state.error}</p>
          <button type="button" onClick={retry}>Try again</button>
        </div>
      )}
      {state.status === 'ready' && state.products.length > 0 && (
        <ul aria-label="Product list">
          {state.products.map((p) => (
            <li key={p.id}>
              <h3>{p.name}</h3>
              <p>{formatPrice(p.pricePaise)}</p>
              <p>{p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'}</p>
              <button type="button" disabled={!canAdd || p.stock === 0} onClick={() => onAdd(p)} aria-label={`Add ${p.name} to cart`}>
                Add to cart
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
