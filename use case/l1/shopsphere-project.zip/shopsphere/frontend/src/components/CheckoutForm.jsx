import { useState } from 'react';

export default function CheckoutForm({ onSubmit, disabled }) {
  const [form, setForm] = useState({ paymentToken: '', couponCode: '' });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const update = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }));

  async function handleSubmit(e) {
    e.preventDefault();
    if (submitting) return; // blocks double-submit (double charge risk)
    if (!form.paymentToken.trim()) {
      setErrors({ paymentToken: 'Enter a payment token' });
      return;
    }
    setErrors({});
    setSubmitting(true);
    try {
      await onSubmit({ paymentToken: form.paymentToken.trim(), couponCode: form.couponCode.trim() || undefined });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} noValidate aria-labelledby="checkout-heading">
      <h2 id="checkout-heading">Checkout</h2>
      <div>
        <label htmlFor="paymentToken">Payment token</label>
        <input id="paymentToken" value={form.paymentToken} onChange={update('paymentToken')}
          aria-invalid={Boolean(errors.paymentToken)} aria-describedby={errors.paymentToken ? 'paymentToken-error' : 'paymentToken-hint'} />
        <p id="paymentToken-hint">Demo tokens: tok_ok, tok_declined, tok_timeout</p>
        {errors.paymentToken && <p id="paymentToken-error" role="alert">{errors.paymentToken}</p>}
      </div>
      <div>
        <label htmlFor="couponCode">Coupon code (optional)</label>
        <input id="couponCode" value={form.couponCode} onChange={update('couponCode')} autoComplete="off" />
      </div>
      <button type="submit" disabled={disabled || submitting}>{submitting ? 'Placing order…' : 'Place order'}</button>
    </form>
  );
}
