// Lists the license of every installed production dependency and flags non-permissive ones.
import fs from 'node:fs';
import path from 'node:path';
const ALLOWED = ['MIT', 'ISC', 'BSD-2-Clause', 'BSD-3-Clause', 'Apache-2.0', '0BSD', 'BlueOak-1.0.0', 'Python-2.0', 'CC0-1.0'];
const root = process.argv[2];
const direct = Object.keys(JSON.parse(fs.readFileSync(path.join(root, 'package.json'))).dependencies || {});
const seen = new Map();
direct.forEach((n) => (function w(name) {
  if (seen.has(name)) return;
  const pj = path.join(root, 'node_modules', name, 'package.json');
  if (!fs.existsSync(pj)) return;
  const j = JSON.parse(fs.readFileSync(pj));
  seen.set(name, typeof j.license === 'string' ? j.license : JSON.stringify(j.license || j.licenses || 'UNKNOWN'));
  Object.keys(j.dependencies || {}).forEach(w);
})(n));
const counts = {};
for (const lic of seen.values()) counts[lic] = (counts[lic] || 0) + 1;
console.log(`${root}: ${seen.size} production packages (direct: ${direct.join(', ')})`);
console.log('licenses:', JSON.stringify(counts));
const risky = [...seen].filter(([, l]) => !ALLOWED.some((a) => l.includes(a)));
console.log(risky.length ? `REVIEW NEEDED: ${risky.map(([n, l]) => `${n} (${l})`).join(', ')}` : 'No copyleft or unknown licenses found.');
