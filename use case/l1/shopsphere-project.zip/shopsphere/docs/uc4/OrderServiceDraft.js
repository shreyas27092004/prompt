// FIRST-DRAFT code, as an AI might produce it WITHOUT the review checklist. Contains deliberate flaws.
import crypto from 'node:crypto';

const PAYMENT_API_KEY = 'sk_live_51HqXyZabcdef123456'; // hardcoded secret

export function placeOrder(user, cart, coupon, gateway) {
  const orderId = crypto.randomUUIDv7();                    // hallucinated API: no such function in node:crypto
  let total = 0;
  for (const item of cart.items) {                          // no null check on cart / cart.items
    if (item.quantity > 0) {
      if (item.product.stock >= item.quantity) {
        if (coupon) {
          if (coupon === 'SAVE10') {
            total += item.product.price * item.quantity * 0.9;
          } else if (coupon === 'FESTIVE25') {
            total += item.product.price * item.quantity * 0.75;
          } else if (coupon === 'VIP') {
            total += item.product.price * item.quantity * 0.5;
          } else {
            total += item.product.price * item.quantity;
          }
        } else {
          total += item.product.price * item.quantity;
        }
      } else {
        throw new Error('stock');
      }
    }
  }
  gateway.charge(total, PAYMENT_API_KEY);                   // not awaited, floating-point money
  return { id: orderId, userId: user.id, total };           // user may be undefined
}
