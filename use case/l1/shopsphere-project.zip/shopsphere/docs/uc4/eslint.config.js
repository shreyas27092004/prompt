export default [{
  files: ['*.js'],
  languageOptions: { ecmaVersion: 2023, sourceType: 'module' },
  // Sonar-style rules: cyclomatic complexity and nesting depth.
  rules: { complexity: ['warn', 8], 'max-depth': ['warn', 4], 'max-params': ['warn', 3] },
}];
