# ADR-003: Modular monolith for the first delivery, with microservice boundaries

**Status:** Accepted

**Context:** ADR-001 sets microservices as the target. This project is a small, learning-sized build that has to run on a laptop with in-memory storage.

**Decision:** Deliver one Express application organised as five modules (catalog, cart, orders, payments, users). Each module owns its data and talks to the others only through a small interface (for example the Cart module calls catalog.getProduct, the Order module calls catalog.reserveStock and payments.charge). The OpenAPI contract is already split by service area.

**Consequences:**
- (+) One process to run, debug and test; end-to-end tests are simple.
- (+) Each module can be moved into its own service later by replacing the in-process call with an HTTP call or an event, without changing the public API.
- (-) Not yet independently scalable; the 10,000-user target is not load-tested in this delivery.
