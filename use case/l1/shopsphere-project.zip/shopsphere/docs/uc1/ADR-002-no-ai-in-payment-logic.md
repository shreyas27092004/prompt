# ADR-002: AI must not be used inside payment processing logic

**Status:** Accepted

**Context:** AI is used in this project at design time (requirements, scaffolding, review, tests). The question is whether an AI model may also make decisions at run time inside the payment flow, for example approving charges, calculating totals or deciding refunds.

**Decision:** No AI/LLM component is part of the payment processing logic. Amounts, discounts, charges, retries and refunds are computed by deterministic, reviewed and tested code. AI may help write and test that code, but it never runs inside it.

**Reasons:**
- Determinism: the same input must always give the same amount. LLM output can vary between calls.
- Auditability: every payment decision must be explainable and reproducible for finance and regulators.
- Security and compliance (PCI-DSS): sending card or payment data to an external model widens the compliance scope and risks data leakage.
- Correctness: LLMs can produce plausible but wrong numbers (hallucination); a wrong amount is a financial loss and a legal problem.
- Liability: responsibility for a wrong charge cannot be passed to a model.

**Consequences:** Payment code is covered by unit tests and a security test suite (declined, timeout, idempotency, price tampering). AI-generated payment code must pass human review before merge.

**Where AI is appropriate:** requirement analysis, API contract drafting, scaffolding, UI generation, test generation, code review assistance.
