import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(new URL('../../backend/package.json', import.meta.url));
const Ajv = require('ajv');
const read = f => JSON.parse(fs.readFileSync(new URL(f, import.meta.url)));
const arch = read('./architecture.json');
const reqs = read('./requirements.json');
const validate = new Ajv({ allErrors: true }).compile(read('./architecture.schema.json'));
const ok = validate(arch);
console.log('architecture.json schema valid:', ok);
if (!ok) { console.log(validate.errors); process.exit(1); }
// traceability check: every traced requirement id must exist
const ids = new Set([...reqs.functional, ...reqs.non_functional].map(r => r.id));
const missing = arch.services.flatMap(s => s.traced_requirements).filter(id => !ids.has(id));
console.log('unknown requirement ids:', missing.length ? missing : 'none');
const covered = new Set(arch.services.flatMap(s => s.traced_requirements));
const uncovered = reqs.functional.map(r => r.id).filter(id => !covered.has(id));
console.log('functional requirements not covered by any service:', uncovered.length ? uncovered : 'none');
process.exit(missing.length || uncovered.length ? 1 : 0);
