# ADR-001: Microservices as the target architecture

**Status:** Accepted

**Context:** ShopSphere must support 10,000 concurrent users. Browsing (Catalog) receives far more traffic than Checkout (Order, Payment). Payment providers can be slow or unavailable, and that must not stop customers from browsing.

**Decision:** The target architecture is five services (Catalog, Cart, Order, Payment, User), each owning its own database and exposing REST APIs defined contract-first in OpenAPI. Services communicate synchronously over REST where a result is needed immediately, and asynchronously through RabbitMQ for events such as OrderPaid.

**Consequences:**
- (+) Catalog and Cart can be scaled independently of Order and Payment.
- (+) A Payment outage is isolated; browsing and cart keep working.
- (+) Teams can deploy their service independently.
- (-) More operational work: service discovery, tracing, per-service deployment.
- (-) No cross-service database transactions; consistency relies on events, retries and idempotency.

**Alternatives considered:** a single monolith (simplest, but the whole application scales as one unit and one failure can affect everything).
