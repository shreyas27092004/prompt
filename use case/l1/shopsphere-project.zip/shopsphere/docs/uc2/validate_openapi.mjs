// Validation layer for AI-generated OpenAPI YAML. Exit code 1 = reject (retry or re-prompt).
import fs from 'node:fs';
import { createRequire } from 'node:module';
const require = createRequire(new URL('../../backend/package.json', import.meta.url));
const { load } = require('js-yaml');

export function validateOpenApi(text) {
  const problems = [];
  let spec;
  try { spec = load(text); } catch (e) { return [`YAML parse error: ${e.message.split('\n')[0]}`]; }
  if (!spec || typeof spec !== 'object') return ['Document is not a YAML object'];
  if (!String(spec.openapi || '').startsWith('3.0')) problems.push('openapi must be 3.0.x');
  if (!spec.info?.version) problems.push('info.version missing');
  if (!spec.paths || Object.keys(spec.paths).length === 0) problems.push('no paths defined');
  const schemas = spec.components?.schemas || {};
  if (!schemas.Error) problems.push('components.schemas.Error (shared error model) missing');
  const refs = [...text.matchAll(/\$ref:\s*'?#\/components\/(\w+)\/(\w+)/g)];
  for (const [, kind, name] of refs) if (!spec.components?.[kind]?.[name]) problems.push(`unresolved $ref #/components/${kind}/${name}`);
  for (const [path, ops] of Object.entries(spec.paths || {})) {
    for (const [method, op] of Object.entries(ops)) {
      if (!op.responses) { problems.push(`${method.toUpperCase()} ${path}: no responses`); continue; }
      const codes = Object.keys(op.responses);
      if (!codes.some((c) => c.startsWith('2'))) problems.push(`${method.toUpperCase()} ${path}: no 2xx response`);
      if (path.includes('{') && !codes.includes('404')) problems.push(`${method.toUpperCase()} ${path}: path parameter but no 404 response`);
      if (method === 'post' && !codes.includes('400')) problems.push(`${method.toUpperCase()} ${path}: POST without 400 response`);
    }
  }
  return [...new Set(problems)];
}

if (process.argv[1].endsWith('validate_openapi.mjs')) {
  const file = process.argv[2];
  const problems = validateOpenApi(fs.readFileSync(file, 'utf8'));
  console.log(problems.length ? `REJECT ${file}\n - ${problems.join('\n - ')}` : `ACCEPT ${file}`);
  process.exit(problems.length ? 1 : 0);
}
