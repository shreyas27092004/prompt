// Demonstrates RETRY vs RE-PROMPT using three recorded "attempts" at generating the OpenAPI file.
import fs from 'node:fs';
import { validateOpenApi } from './validate_openapi.mjs';

const full = fs.readFileSync(new URL('../../backend/openapi.yaml', import.meta.url), 'utf8');
const attempts = [
  { label: 'Attempt 1 (max_tokens too low -> output cut off mid-file)', text: full.slice(0, 2600) },
  { label: 'Attempt 2 (RETRY with same prompt, max_tokens still low -> same truncation)', text: full.slice(0, 2600) },
  { label: 'Attempt 3 (RE-PROMPT: smaller scope + higher max_tokens -> complete file)', text: full },
];
for (const [i, a] of attempts.entries()) {
  const problems = validateOpenApi(a.text);
  console.log(`[attempt ${i + 1}] ${a.label}`);
  console.log(`   output size: ${a.text.length} chars -> ${problems.length ? 'REJECTED' : 'ACCEPTED'}`);
  for (const p of problems) console.log(`   - ${p}`);
}
