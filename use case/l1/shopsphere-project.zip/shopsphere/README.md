# ShopSphere: AI-assisted Online Shopping System

Small full-stack project built through the five prompt-driven use cases documented in `ShopSphere_AI_Prompt_Playbook.docx`.

## Run
```bash
# backend (Node 22+)
cd backend && npm install && npm start        # http://localhost:3000/api/v1
npm test                                        # 30 tests
npm run coverage                                # coverage report
npm run lint                                    # complexity / nesting rules

# frontend
cd frontend && npm install && npm run dev       # http://localhost:5173 (proxies /api to :3000)
npm test                                        # 18 tests incl. accessibility (axe)
```
Seed login: `admin@shop.test` / `admin12345` (ADMIN). Register any other user from the API.
Demo payment tokens: `tok_ok`, `tok_declined`, `tok_timeout`. Coupons: `SAVE10`, `FESTIVE25`.

## Layout
- `backend/openapi.yaml`: the API contract (contract-first)
- `backend/src/modules/`: catalog, cart, orders, payments, users
- `frontend/src/components/`: ProductList, Cart, CheckoutForm
- `docs/`: use-case artifacts (UC1 to UC5) and `docs/evidence/` (real command output quoted in the Word document)
