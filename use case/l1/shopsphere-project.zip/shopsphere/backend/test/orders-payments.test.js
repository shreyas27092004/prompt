import test from 'node:test';
import assert from 'node:assert/strict';
import { startApp } from '../support/helpers.js';
import { calculateTotals } from '../src/modules/orders.js';
import { createPaymentModule } from '../src/modules/payments.js';

async function cartWith(app, name, quantity) {
  const token = await app.registerAndLogin();
  const p = await app.firstProduct(name);
  await app.call('POST', '/cart/items', { token, body: { productId: p.id, quantity } });
  return { token, product: p };
}
const stockOf = async (app, id) => (await app.call('GET', `/products/${id}`)).body.stock;

test('orders: successful checkout charges, reduces stock, clears cart, lists order', async () => {
  const app = await startApp();
  try {
    const { token, product } = await cartWith(app, 'Notebook (A5)', 4);
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok' } });
    assert.equal(r.status, 201);
    assert.equal(r.body.totalPaise, 4 * 14900);
    assert.equal(r.body.status, 'PAID');
    assert.equal(await stockOf(app, product.id), 96);
    assert.deepEqual((await app.call('GET', '/cart', { token })).body.items, []);
    assert.equal((await app.call('GET', '/orders', { token })).body.length, 1);
  } finally { app.close(); }
});

test('orders: valid coupon applies discount; invalid coupon -> 400 and nothing is charged', async () => {
  const app = await startApp();
  try {
    const { token, product } = await cartWith(app, 'Wireless Mouse', 1);
    const bad = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok', couponCode: 'FAKE99' } });
    assert.equal(bad.status, 400);
    assert.match(bad.body.details[0], /FAKE99/);
    assert.equal(await stockOf(app, product.id), 25, 'stock untouched after invalid coupon');
    const ok = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok', couponCode: 'save10' } });
    assert.equal(ok.status, 201);
    assert.equal(ok.body.discountPaise, 7990);
    assert.equal(ok.body.totalPaise, 79900 - 7990);
    assert.equal(ok.body.coupon, 'SAVE10');
  } finally { app.close(); }
});

test('orders: empty cart and missing payment token -> 400', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    assert.equal((await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok' } })).body.message, 'Cart is empty');
    assert.equal((await app.call('POST', '/orders', { token, body: {} })).status, 400);
  } finally { app.close(); }
});

test('cart: once the last units are bought, further adds are rejected with 409', async () => {
  const app = await startApp();
  try {
    const first = await cartWith(app, 'Desk Lamp', 3);
    assert.equal((await app.call('POST', '/orders', { token: first.token, body: { paymentToken: 'tok_ok' } })).status, 201);
    const late = await app.registerAndLogin();
    const r = await app.call('POST', '/cart/items', { token: late, body: { productId: first.product.id, quantity: 1 } });
    assert.equal(r.status, 409, 'stock is now 0');
  } finally { app.close(); }
});

test('orders: stock sold out between add-to-cart and checkout -> 409 and no payment attempt', async () => {
  let charges = 0;
  const gateway = { async charge() { charges += 1; return { gatewayRef: 'x' }; } };
  const app = await startApp({ gateway });
  try {
    const a = await cartWith(app, 'Desk Lamp', 2);
    const b = await cartWith(app, 'Desk Lamp', 2);
    assert.equal((await app.call('POST', '/orders', { token: a.token, body: { paymentToken: 't' } })).status, 201);
    const r = await app.call('POST', '/orders', { token: b.token, body: { paymentToken: 't' } });
    assert.equal(r.status, 409);
    assert.equal(charges, 1, 'second buyer must not be charged');
    assert.equal((await app.call('GET', '/cart', { token: b.token })).body.items.length, 1, 'cart kept so the user can adjust');
  } finally { app.close(); }
});

test('payment: declined card -> 402, stock restored, no order created', async () => {
  const app = await startApp();
  try {
    const { token, product } = await cartWith(app, 'Wireless Mouse', 2);
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_declined' } });
    assert.equal(r.status, 402);
    assert.equal(r.body.code, 'PAYMENT_DECLINED');
    assert.equal(await stockOf(app, product.id), 25);
    assert.equal((await app.call('GET', '/orders', { token })).body.length, 0);
    assert.equal((await app.call('GET', '/cart', { token })).body.items.length, 1);
  } finally { app.close(); }
});

test('payment: timeout -> 504, stock restored, no order created', async () => {
  const app = await startApp();
  try {
    const { token, product } = await cartWith(app, 'Wireless Mouse', 2);
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_timeout' } });
    assert.equal(r.status, 504);
    assert.equal(r.body.code, 'PAYMENT_TIMEOUT');
    assert.equal(await stockOf(app, product.id), 25);
    assert.equal((await app.call('GET', '/orders', { token })).body.length, 0);
  } finally { app.close(); }
});

test('payment: same idempotency key is charged only once', async () => {
  let charges = 0;
  const gateway = { async charge({ amountPaise }) { charges += 1; return { gatewayRef: `ch_${charges}`, amountPaise }; } };
  const payments = createPaymentModule({ gateway, timeoutMs: 50 });
  const a = await payments.charge({ amountPaise: 100, token: 't', idempotencyKey: 'k1' });
  const b = await payments.charge({ amountPaise: 100, token: 't', idempotencyKey: 'k1' });
  assert.equal(charges, 1);
  assert.equal(a.id, b.id);
});

test('orders: users cannot read each other\'s orders (404, not 403)', async () => {
  const app = await startApp();
  try {
    const a = await cartWith(app, 'Notebook (A5)', 1);
    const order = (await app.call('POST', '/orders', { token: a.token, body: { paymentToken: 'tok_ok' } })).body;
    const other = await app.registerAndLogin();
    assert.equal((await app.call('GET', `/orders/${order.id}`, { token: other })).status, 404);
    assert.equal((await app.call('GET', `/orders/${order.id}`, { token: a.token })).status, 200);
    assert.equal((await app.call('GET', '/orders')).status, 401);
  } finally { app.close(); }
});

test('security: tampered price in the request body is ignored (server prices the cart)', async () => {
  const app = await startApp();
  try {
    const { token } = await cartWith(app, 'Mechanical Keyboard', 1);
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok', totalPaise: 1, pricePaise: 1 } });
    assert.equal(r.body.totalPaise, 349900);
  } finally { app.close(); }
});

test('totals: discount uses integer rounding (no fractional paise)', () => {
  assert.deepEqual(calculateTotals(999, 'SAVE10'), { subtotalPaise: 999, discountPaise: 99, totalPaise: 900 });
  assert.deepEqual(calculateTotals(0, 'SAVE10'), { subtotalPaise: 0, discountPaise: 0, totalPaise: 0 });
  assert.deepEqual(calculateTotals(500, ''), { subtotalPaise: 500, discountPaise: 0, totalPaise: 500 });
});

test('api: malformed JSON -> 400 with error model; unknown route -> 404 with error model', async () => {
  const app = await startApp();
  try {
    const bad = await app.raw('POST', '/auth/login', '{not json');
    assert.equal(bad.status, 400);
    assert.deepEqual(Object.keys(bad.body).sort(), ['code', 'details', 'message', 'traceId']);
    const missing = await app.call('GET', '/nothing-here');
    assert.equal(missing.status, 404);
    assert.equal(missing.body.code, 'NOT_FOUND');
  } finally { app.close(); }
});

test('api: unexpected gateway failure -> 500 with error model and no internal details leaked', async () => {
  const gateway = { async charge() { throw new Error('db password is hunter2'); } };
  const app = await startApp({ gateway });
  const originalError = console.error;
  console.error = () => {}; // keep test output clean; the server logs the real error
  try {
    const { token, product } = await cartWith(app, 'Notebook (A5)', 1);
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok' } });
    assert.equal(r.status, 500);
    assert.equal(r.body.code, 'INTERNAL_ERROR');
    assert.equal(JSON.stringify(r.body).includes('hunter2'), false);
    assert.equal(await stockOf(app, product.id), 100, 'stock restored after unexpected failure');
  } finally { console.error = originalError; app.close(); }
});

test('security (UC4 finding): idempotency keys are scoped per user, one user cannot replay another\'s payment', async () => {
  const payments = createPaymentModule({ gateway: { async charge({ amountPaise }) { return { gatewayRef: `ch_${amountPaise}`, amountPaise }; } }, timeoutMs: 50 });
  const alice = await payments.charge({ amountPaise: 100, token: 't', idempotencyKey: 'shared-key', userId: 'alice' });
  const bob = await payments.charge({ amountPaise: 999, token: 't', idempotencyKey: 'shared-key', userId: 'bob' });
  assert.notEqual(bob.id, alice.id);
  assert.equal(bob.amountPaise, 999, 'bob must be charged his own amount, not get alice\'s cached result');
});

test('security (UC4 finding): coupon lookup ignores prototype keys like "constructor"', () => {
  assert.throws(() => calculateTotals(1000, 'constructor'), /Invalid coupon/);
  assert.throws(() => calculateTotals(1000, '__proto__'), /Invalid coupon/);
});
