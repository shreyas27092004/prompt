import test from 'node:test';
import assert from 'node:assert/strict';
import { startApp } from '../support/helpers.js';

test('cart: normal flow add -> update -> remove with correct totals', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    const mouse = await app.firstProduct('Wireless Mouse');
    let r = await app.call('POST', '/cart/items', { token, body: { productId: mouse.id, quantity: 2 } });
    assert.equal(r.body.totalPaise, 2 * 79900);
    r = await app.call('POST', '/cart/items', { token, body: { productId: mouse.id, quantity: 1 } });
    assert.equal(r.body.items[0].quantity, 3, 'adding the same product again increases quantity');
    r = await app.call('PATCH', `/cart/items/${mouse.id}`, { token, body: { quantity: 1 } });
    assert.equal(r.body.totalPaise, 79900);
    r = await app.call('DELETE', `/cart/items/${mouse.id}`, { token });
    assert.deepEqual(r.body, { items: [], totalPaise: 0 });
  } finally { app.close(); }
});

test('cart: empty cart returns zero total', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    assert.deepEqual((await app.call('GET', '/cart', { token })).body, { items: [], totalPaise: 0 });
  } finally { app.close(); }
});

test('cart: boundary quantities (0, negative, decimal, exactly stock, stock+1, huge)', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    const lamp = await app.firstProduct('Desk Lamp'); // stock = 3
    const add = (quantity) => app.call('POST', '/cart/items', { token, body: { productId: lamp.id, quantity } });
    for (const bad of [0, -1, 1.5, '2', null]) assert.equal((await add(bad)).status, 400, `quantity ${bad}`);
    assert.equal((await add(3)).status, 200, 'exactly the stock is allowed');
    const over = await add(1);
    assert.equal(over.status, 409, 'stock + 1 is rejected');
    assert.match(over.body.message, /Only 3 unit/);
    assert.equal((await add(Number.MAX_SAFE_INTEGER)).status, 409);
  } finally { app.close(); }
});

test('cart: invalid product id -> 404; removing an absent item -> 404; needs login -> 401', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    assert.equal((await app.call('POST', '/cart/items', { token, body: { productId: 'nope', quantity: 1 } })).status, 404);
    assert.equal((await app.call('DELETE', '/cart/items/nope', { token })).status, 404);
    assert.equal((await app.call('PATCH', '/cart/items/nope', { token, body: { quantity: 1 } })).status, 404);
    assert.equal((await app.call('GET', '/cart')).status, 401);
  } finally { app.close(); }
});

test('cart: carts are private per user', async () => {
  const app = await startApp();
  try {
    const a = await app.registerAndLogin();
    const b = await app.registerAndLogin();
    const p = await app.firstProduct('Notebook (A5)');
    await app.call('POST', '/cart/items', { token: a, body: { productId: p.id, quantity: 1 } });
    assert.equal((await app.call('GET', '/cart', { token: b })).body.items.length, 0);
  } finally { app.close(); }
});

test('cart: concurrent additions never exceed stock', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    const lamp = await app.firstProduct('Desk Lamp'); // stock = 3
    const results = await Promise.all(
      Array.from({ length: 10 }, () => app.call('POST', '/cart/items', { token, body: { productId: lamp.id, quantity: 1 } })),
    );
    assert.ok(results.some((r) => r.status === 409), 'at least one request must be rejected');
    const cart = await app.call('GET', '/cart', { token });
    assert.ok(cart.body.items[0].quantity <= 3, `cart holds ${cart.body.items[0].quantity}, stock is 3`);
  } finally { app.close(); }
});
