import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { load } from 'js-yaml';
import Ajv from 'ajv';
import { startApp } from '../support/helpers.js';

const spec = load(fs.readFileSync(new URL('../openapi.yaml', import.meta.url), 'utf8'));
const ajv = new Ajv({ strict: false, allErrors: true });
// Resolve $ref pointers like '#/components/schemas/Product' against the spec itself.
ajv.addSchema({ $id: 'spec', components: spec.components });
const schemaFor = (name) => ajv.compile({ $ref: `spec#/components/schemas/${name}` });

test('contract: every documented operation has a route (no 404 ROUTE not found)', async () => {
  const app = await startApp();
  try {
    for (const [path, ops] of Object.entries(spec.paths)) {
      for (const method of Object.keys(ops)) {
        const url = path.replace(/{[^}]+}/g, 'x');
        const m = method.toUpperCase();
        const r = await app.call(m, url, m === 'GET' ? {} : { body: {} });
        const isRouteMissing = r.status === 404 && /Route .* not found/.test(r.body.message);
        assert.equal(isRouteMissing, false, `${method.toUpperCase()} ${path} is in openapi.yaml but not implemented`);
      }
    }
  } finally { app.close(); }
});

test('contract: GET /products response matches ProductPage schema', async () => {
  const app = await startApp();
  try {
    const r = await app.call('GET', '/products');
    const validate = schemaFor('ProductPage');
    assert.equal(validate(r.body), true, JSON.stringify(validate.errors));
  } finally { app.close(); }
});

test('contract: error responses match the shared Error schema (400, 401, 404)', async () => {
  const app = await startApp();
  try {
    const validate = schemaFor('Error');
    const responses = [
      await app.call('GET', '/products?page=0'),
      await app.call('GET', '/cart'),
      await app.call('GET', '/products/does-not-exist'),
    ];
    assert.deepEqual(responses.map((r) => r.status), [400, 401, 404]);
    for (const r of responses) assert.equal(validate(r.body), true, JSON.stringify(validate.errors));
  } finally { app.close(); }
});

test('contract: checkout order response matches Order schema', async () => {
  const app = await startApp();
  try {
    const token = await app.registerAndLogin();
    const p = await app.firstProduct('Notebook (A5)');
    await app.call('POST', '/cart/items', { token, body: { productId: p.id, quantity: 2 } });
    const r = await app.call('POST', '/orders', { token, body: { paymentToken: 'tok_ok' } });
    assert.equal(r.status, 201);
    const validate = schemaFor('Order');
    assert.equal(validate(r.body), true, JSON.stringify(validate.errors));
  } finally { app.close(); }
});
