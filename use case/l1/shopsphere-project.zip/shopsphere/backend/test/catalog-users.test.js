import test from 'node:test';
import assert from 'node:assert/strict';
import { startApp } from '../support/helpers.js';

test('catalog: pagination returns the requested slice and total', async () => {
  const app = await startApp();
  try {
    const r = await app.call('GET', '/products?page=2&size=3');
    assert.equal(r.status, 200);
    assert.equal(r.body.items.length, 1);
    assert.equal(r.body.total, 4);
  } finally { app.close(); }
});

test('catalog: category filter and invalid size are handled', async () => {
  const app = await startApp();
  try {
    assert.equal((await app.call('GET', '/products?category=home')).body.total, 1);
    assert.equal((await app.call('GET', '/products?size=101')).status, 400);
    assert.equal((await app.call('GET', '/products?size=abc')).status, 400);
  } finally { app.close(); }
});

test('catalog: only admin can create; duplicate name -> 409; invalid body -> 400', async () => {
  const app = await startApp();
  try {
    const user = await app.registerAndLogin();
    const admin = await app.login('admin@shop.test', 'admin12345');
    const body = { name: 'USB Hub', pricePaise: 49900, stock: 5, category: 'electronics' };
    assert.equal((await app.call('POST', '/products', { body })).status, 401);
    assert.equal((await app.call('POST', '/products', { token: user, body })).status, 403);
    assert.equal((await app.call('POST', '/products', { token: admin, body })).status, 201);
    assert.equal((await app.call('POST', '/products', { token: admin, body })).status, 409);
    const bad = await app.call('POST', '/products', { token: admin, body: { name: '', pricePaise: -1, stock: 1.5 } });
    assert.equal(bad.status, 400);
    assert.ok(bad.body.details.length >= 3);
  } finally { app.close(); }
});

test('users: register, duplicate, weak password, login, me', async () => {
  const app = await startApp();
  try {
    const creds = { email: 'Asha@Shop.test', password: 'password123' };
    assert.equal((await app.call('POST', '/users/register', { body: creds })).status, 201);
    assert.equal((await app.call('POST', '/users/register', { body: { ...creds, email: 'asha@shop.test' } })).status, 409);
    assert.equal((await app.call('POST', '/users/register', { body: { email: 'x@y.co', password: 'short' } })).status, 400);
    assert.equal((await app.call('POST', '/users/register', { body: { email: 'not-an-email', password: 'password123' } })).status, 400);
    const login = await app.call('POST', '/auth/login', { body: creds });
    assert.equal(login.status, 200);
    const me = await app.call('GET', '/users/me', { token: login.body.token });
    assert.equal(me.body.email, 'asha@shop.test');
    assert.equal('passwordHash' in me.body, false, 'password hash must never be returned');
  } finally { app.close(); }
});

test('users: wrong password and unknown email give the same 401 message', async () => {
  const app = await startApp();
  try {
    const wrong = await app.call('POST', '/auth/login', { body: { email: 'admin@shop.test', password: 'wrongpass1' } });
    const unknown = await app.call('POST', '/auth/login', { body: { email: 'nobody@shop.test', password: 'wrongpass1' } });
    assert.equal(wrong.status, 401);
    assert.equal(unknown.status, 401);
    assert.equal(wrong.body.message, unknown.body.message);
    assert.equal((await app.call('GET', '/users/me', { token: 'forged-token' })).status, 401);
  } finally { app.close(); }
});
