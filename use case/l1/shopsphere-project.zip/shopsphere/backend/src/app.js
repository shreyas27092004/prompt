import express from 'express';
import { errorHandler, notFound } from './errors.js';
import { createUserModule } from './modules/users.js';
import { createCatalogModule } from './modules/catalog.js';
import { createCartModule } from './modules/cart.js';
import { createOrderModule } from './modules/orders.js';
import { createMockGateway, createPaymentModule } from './modules/payments.js';

export function createApp({ gateway = createMockGateway(), paymentTimeoutMs = 50, seed = true } = {}) {
  const users = createUserModule();
  const catalog = createCatalogModule({ authenticate: users.authenticate });
  const cart = createCartModule({ authenticate: users.authenticate, catalog });
  const payments = createPaymentModule({ gateway, timeoutMs: paymentTimeoutMs });
  const orders = createOrderModule({ authenticate: users.authenticate, cart, catalog, payments });

  if (seed) {
    users.addUser('admin@shop.test', 'admin12345', 'ADMIN');
    catalog.addProduct({ name: 'Wireless Mouse', pricePaise: 79900, stock: 25, category: 'electronics' });
    catalog.addProduct({ name: 'Mechanical Keyboard', pricePaise: 349900, stock: 10, category: 'electronics' });
    catalog.addProduct({ name: 'Notebook (A5)', pricePaise: 14900, stock: 100, category: 'stationery' });
    catalog.addProduct({ name: 'Desk Lamp', pricePaise: 129900, stock: 3, category: 'home' });
  }

  const app = express();
  app.use(express.json());
  app.use('/api/v1', users.router, catalog.router, cart.router, orders.router);
  app.use((req, _res, next) => next(notFound(`Route ${req.method} ${req.path} not found`)));
  app.use(errorHandler);
  return app;
}
