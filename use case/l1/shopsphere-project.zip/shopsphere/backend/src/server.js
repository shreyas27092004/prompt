import { createApp } from './app.js';

const port = process.env.PORT || 3000;
createApp().listen(port, () => console.log(`ShopSphere API listening on http://localhost:${port}/api/v1`));
