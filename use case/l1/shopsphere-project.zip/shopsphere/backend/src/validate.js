import { badRequest } from './errors.js';

export function requireString(obj, field, errors, { min = 1 } = {}) {
  if (typeof obj?.[field] !== 'string' || obj[field].trim().length < min) {
    errors.push(`${field} must be a string of at least ${min} character(s)`);
  }
}

export function requireInt(obj, field, errors, { min = 0 } = {}) {
  const v = obj?.[field];
  if (!Number.isInteger(v) || v < min) errors.push(`${field} must be an integer >= ${min}`);
}

export function failIfInvalid(errors) {
  if (errors.length) throw badRequest('Validation failed', errors);
}
