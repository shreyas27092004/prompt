import { Router } from 'express';
import { randomBytes, randomUUID, scryptSync, timingSafeEqual } from 'node:crypto';
import { conflict, unauthorized } from '../errors.js';
import { failIfInvalid } from '../validate.js';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function hashPassword(password, salt = randomBytes(16).toString('hex')) {
  return `${salt}:${scryptSync(password, salt, 32).toString('hex')}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const candidate = scryptSync(password, salt, 32);
  return timingSafeEqual(candidate, Buffer.from(hash, 'hex'));
}

const publicUser = (u) => ({ id: u.id, email: u.email, role: u.role });

export function createUserModule() {
  const users = new Map(); // email -> user
  const sessions = new Map(); // token -> userId
  const byId = new Map();

  function addUser(email, password, role = 'USER') {
    const user = { id: randomUUID(), email: email.toLowerCase(), passwordHash: hashPassword(password), role };
    users.set(user.email, user);
    byId.set(user.id, user);
    return user;
  }

  function credentialErrors(body) {
    const errors = [];
    if (typeof body?.email !== 'string' || !EMAIL_RE.test(body.email)) errors.push('email must be a valid email address');
    if (typeof body?.password !== 'string' || body.password.length < 8) errors.push('password must be at least 8 characters');
    failIfInvalid(errors);
  }

  const router = Router();
  router.post('/users/register', (req, res) => {
    credentialErrors(req.body);
    if (users.has(req.body.email.toLowerCase())) throw conflict('Email already registered');
    res.status(201).json(publicUser(addUser(req.body.email, req.body.password)));
  });

  router.post('/auth/login', (req, res) => {
    credentialErrors(req.body);
    const user = users.get(req.body.email.toLowerCase());
    // Same message for unknown email and wrong password: do not reveal which accounts exist.
    if (!user || !verifyPassword(req.body.password, user.passwordHash)) throw unauthorized('Invalid email or password');
    const token = randomBytes(24).toString('hex');
    sessions.set(token, user.id);
    res.json({ token, user: publicUser(user) });
  });

  function authenticate(req, _res, next) {
    const header = req.get('authorization') || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : '';
    const user = byId.get(sessions.get(token));
    if (!user) return next(unauthorized());
    req.user = user;
    next();
  }

  router.get('/users/me', authenticate, (req, res) => res.json(publicUser(req.user)));

  return { router, authenticate, addUser };
}
