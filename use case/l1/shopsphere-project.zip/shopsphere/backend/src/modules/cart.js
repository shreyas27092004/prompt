import { Router } from 'express';
import { conflict, notFound } from '../errors.js';
import { failIfInvalid, requireInt, requireString } from '../validate.js';

export function createCartModule({ authenticate, catalog }) {
  const carts = new Map(); // userId -> Map(productId -> quantity)

  const cartOf = (userId) => {
    if (!carts.has(userId)) carts.set(userId, new Map());
    return carts.get(userId);
  };

  function view(userId) {
    const items = [...cartOf(userId)].map(([productId, quantity]) => {
      const p = catalog.getProduct(productId);
      return { productId, name: p.name, unitPricePaise: p.pricePaise, quantity };
    });
    return { items, totalPaise: items.reduce((sum, i) => sum + i.unitPricePaise * i.quantity, 0) };
  }

  function setQuantity(userId, productId, quantity) {
    const product = catalog.getProduct(productId);
    if (!product) throw notFound(`Product ${productId} not found`);
    if (quantity > product.stock) {
      throw conflict(`Only ${product.stock} unit(s) of "${product.name}" in stock`, [`requested=${quantity}`, `available=${product.stock}`]);
    }
    cartOf(userId).set(productId, quantity);
  }

  const router = Router();
  router.use('/cart', authenticate);

  router.get('/cart', (req, res) => res.json(view(req.user.id)));

  router.post('/cart/items', (req, res) => {
    const errors = [];
    requireString(req.body, 'productId', errors);
    requireInt(req.body, 'quantity', errors, { min: 1 });
    failIfInvalid(errors);
    const existing = cartOf(req.user.id).get(req.body.productId) || 0;
    setQuantity(req.user.id, req.body.productId, existing + req.body.quantity);
    res.json(view(req.user.id));
  });

  router.patch('/cart/items/:productId', (req, res) => {
    const errors = [];
    requireInt(req.body, 'quantity', errors, { min: 1 });
    failIfInvalid(errors);
    if (!cartOf(req.user.id).has(req.params.productId)) throw notFound('Item is not in the cart');
    setQuantity(req.user.id, req.params.productId, req.body.quantity);
    res.json(view(req.user.id));
  });

  router.delete('/cart/items/:productId', (req, res) => {
    if (!cartOf(req.user.id).delete(req.params.productId)) throw notFound('Item is not in the cart');
    res.json(view(req.user.id));
  });

  return { router, view, clear: (userId) => carts.delete(userId) };
}
