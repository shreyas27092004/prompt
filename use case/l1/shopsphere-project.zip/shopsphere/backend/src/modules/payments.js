import { randomUUID } from 'node:crypto';

export class PaymentTimeoutError extends Error {}
export class PaymentDeclinedError extends Error {}

/** Mock gateway. Special tokens simulate failures so every path can be tested. */
export function createMockGateway({ latencyMs = 5 } = {}) {
  return {
    async charge({ amountPaise, token }) {
      await new Promise((r) => setTimeout(r, token === 'tok_timeout' ? 200 : latencyMs));
      if (token === 'tok_declined') throw new PaymentDeclinedError('Card declined');
      return { gatewayRef: `ch_${randomUUID()}`, amountPaise };
    },
  };
}

export function createPaymentModule({ gateway, timeoutMs = 50 }) {
  const byKey = new Map(); // idempotencyKey -> payment

  return {
    /** Never charges twice for the same idempotency key. Rejects with PaymentTimeoutError after timeoutMs. */
    async charge({ amountPaise, token, idempotencyKey, userId = 'anonymous' }) {
      // Scope the key per user so one user can never replay another user's payment.
      const scopedKey = idempotencyKey ? `${userId}:${idempotencyKey}` : null;
      if (scopedKey && byKey.has(scopedKey)) return byKey.get(scopedKey);
      let timer;
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new PaymentTimeoutError('Payment gateway timed out')), timeoutMs);
      });
      try {
        const result = await Promise.race([gateway.charge({ amountPaise, token }), timeout]);
        const payment = { id: randomUUID(), status: 'SUCCEEDED', ...result };
        if (scopedKey) byKey.set(scopedKey, payment);
        return payment;
      } finally {
        clearTimeout(timer);
      }
    },
  };
}
