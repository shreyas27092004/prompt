import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { badRequest, conflict, forbidden, notFound } from '../errors.js';
import { failIfInvalid, requireInt, requireString } from '../validate.js';

const intOrDefault = (value, fallback) => (value === undefined ? fallback : Number(value));
const isIntBetween = (n, min, max) => Number.isInteger(n) && n >= min && n <= max;

function parsePaging(query) {
  const page = intOrDefault(query.page, 1);
  const size = intOrDefault(query.size, 20);
  const errors = [];
  if (!isIntBetween(page, 1, Infinity)) errors.push('page must be an integer >= 1');
  if (!isIntBetween(size, 1, 100)) errors.push('size must be an integer between 1 and 100');
  if (errors.length) throw badRequest('Invalid query parameters', errors);
  return { page, size };
}

export function createCatalogModule({ authenticate }) {
  const products = new Map();

  function addProduct({ name, pricePaise, stock, category }) {
    const product = { id: randomUUID(), name, pricePaise, stock, category };
    products.set(product.id, product);
    return product;
  }

  const router = Router();

  router.get('/products', (req, res) => {
    const { page, size } = parsePaging(req.query);
    let list = [...products.values()];
    if (req.query.category) list = list.filter((p) => p.category === req.query.category);
    const start = (page - 1) * size;
    res.json({ items: list.slice(start, start + size), page, size, total: list.length });
  });

  router.get('/products/:id', (req, res) => {
    const product = products.get(req.params.id);
    if (!product) throw notFound(`Product ${req.params.id} not found`);
    res.json(product);
  });

  router.post('/products', authenticate, (req, res) => {
    if (req.user.role !== 'ADMIN') throw forbidden('Only admins can create products');
    const errors = [];
    requireString(req.body, 'name', errors);
    requireString(req.body, 'category', errors);
    requireInt(req.body, 'pricePaise', errors);
    requireInt(req.body, 'stock', errors);
    failIfInvalid(errors);
    const duplicate = [...products.values()].some((p) => p.name.toLowerCase() === req.body.name.toLowerCase());
    if (duplicate) throw conflict(`Product "${req.body.name}" already exists`);
    res.status(201).json(addProduct(req.body));
  });

  return {
    router,
    addProduct,
    getProduct: (id) => products.get(id),
    // Atomic check-and-decrement: either every line succeeds or nothing changes.
    reserveStock(lines) {
      for (const { productId, quantity } of lines) {
        const p = products.get(productId);
        if (!p || p.stock < quantity) return false;
      }
      for (const { productId, quantity } of lines) products.get(productId).stock -= quantity;
      return true;
    },
    releaseStock(lines) {
      for (const { productId, quantity } of lines) {
        const p = products.get(productId);
        if (p) p.stock += quantity;
      }
    },
  };
}
