import { Router } from 'express';
import { randomUUID } from 'node:crypto';
import { ApiError, badRequest, conflict, notFound } from '../errors.js';
import { failIfInvalid, requireString } from '../validate.js';
import { PaymentDeclinedError, PaymentTimeoutError } from './payments.js';

// Percent-off coupons. Kept in code for the demo; a real system would store these.
export const COUPONS = { SAVE10: 10, FESTIVE25: 25 };

export function calculateTotals(subtotalPaise, couponCode) {
  if (couponCode === undefined || couponCode === null || couponCode === '') {
    return { subtotalPaise, discountPaise: 0, totalPaise: subtotalPaise };
  }
  const key = String(couponCode).toUpperCase();
  const percent = Object.hasOwn(COUPONS, key) ? COUPONS[key] : undefined;
  if (percent === undefined) throw badRequest('Invalid coupon', [`coupon "${couponCode}" is not recognised`]);
  const discountPaise = Math.floor((subtotalPaise * percent) / 100);
  return { subtotalPaise, discountPaise, totalPaise: subtotalPaise - discountPaise };
}

export function createOrderModule({ authenticate, cart, catalog, payments }) {
  const orders = new Map();
  const router = Router();
  router.use('/orders', authenticate);

  router.post('/orders', async (req, res) => {
    const errors = [];
    requireString(req.body, 'paymentToken', errors);
    failIfInvalid(errors);

    const userId = req.user.id;
    const { items, totalPaise: subtotal } = cart.view(userId);
    if (items.length === 0) throw badRequest('Cart is empty');
    const totals = calculateTotals(subtotal, req.body.couponCode);

    const lines = items.map(({ productId, quantity }) => ({ productId, quantity }));
    if (!catalog.reserveStock(lines)) throw conflict('One or more items are out of stock');

    try {
      await payments.charge({ amountPaise: totals.totalPaise, token: req.body.paymentToken, idempotencyKey: req.body.idempotencyKey, userId });
    } catch (err) {
      catalog.releaseStock(lines); // payment failed: give the stock back, create no order
      if (err instanceof PaymentTimeoutError) throw new ApiError(504, 'PAYMENT_TIMEOUT', 'Payment timed out; you were not charged');
      if (err instanceof PaymentDeclinedError) throw new ApiError(402, 'PAYMENT_DECLINED', 'Payment was declined');
      throw err;
    }

    const order = {
      id: randomUUID(), userId, items, ...totals, status: 'PAID',
      coupon: req.body.couponCode ? String(req.body.couponCode).toUpperCase() : null,
    };
    orders.set(order.id, order);
    cart.clear(userId);
    res.status(201).json(order);
  });

  router.get('/orders', (req, res) => res.json([...orders.values()].filter((o) => o.userId === req.user.id)));

  router.get('/orders/:id', (req, res) => {
    const order = orders.get(req.params.id);
    // Other users' orders look identical to missing ones, so ids cannot be probed.
    if (!order || order.userId !== req.user.id) throw notFound('Order not found');
    res.json(order);
  });

  return { router };
}
