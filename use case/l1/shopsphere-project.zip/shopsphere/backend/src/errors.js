import { randomUUID } from 'node:crypto';

export class ApiError extends Error {
  constructor(status, code, message, details = []) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (message, details) => new ApiError(400, 'BAD_REQUEST', message, details);
export const unauthorized = (message = 'Authentication required') => new ApiError(401, 'UNAUTHORIZED', message);
export const forbidden = (message = 'Not allowed') => new ApiError(403, 'FORBIDDEN', message);
export const notFound = (message) => new ApiError(404, 'NOT_FOUND', message);
export const conflict = (message, details) => new ApiError(409, 'CONFLICT', message, details);

export function errorHandler(err, req, res, _next) {
  const traceId = randomUUID();
  if (err instanceof ApiError) {
    return res.status(err.status).json({ code: err.code, message: err.message, details: err.details, traceId });
  }
  if (err?.type === 'entity.parse.failed') {
    return res.status(400).json({ code: 'BAD_REQUEST', message: 'Malformed JSON body', details: [], traceId });
  }
  console.error(traceId, err);
  return res.status(500).json({ code: 'INTERNAL_ERROR', message: 'Unexpected error', details: [], traceId });
}
