import js from '@eslint/js';

export default [
  js.configs.recommended,
  {
    files: ['src/**/*.js'],
    languageOptions: { ecmaVersion: 2023, sourceType: 'module', globals: { console: 'readonly', process: 'readonly', setTimeout: 'readonly', clearTimeout: 'readonly', Buffer: 'readonly' } },
    rules: {
      'no-unused-vars': ['error', { argsIgnorePattern: '^_' }], complexity: ['warn', 8], 'max-lines-per-function': ['warn', 40], 'no-eval': 'error' },
  },
];
