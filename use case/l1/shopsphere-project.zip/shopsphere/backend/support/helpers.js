import { createApp } from '../src/app.js';

export async function startApp(options) {
  const app = createApp(options);
  const server = await new Promise((resolve) => { const s = app.listen(0, () => resolve(s)); });
  const base = `http://localhost:${server.address().port}/api/v1`;

  async function call(method, path, { token, body } = {}) {
    const res = await fetch(base + path, {
      method,
      headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: body === undefined ? undefined : JSON.stringify(body),
    });
    const text = await res.text();
    return { status: res.status, body: text ? JSON.parse(text) : null };
  }

  async function raw(method, path, text) {
    const res = await fetch(base + path, { method, headers: { 'content-type': 'application/json' }, body: text });
    return { status: res.status, body: await res.json() };
  }

  async function login(email, password) {
    const r = await call('POST', '/auth/login', { body: { email, password } });
    return r.body.token;
  }

  async function registerAndLogin(email = `u${Math.random().toString(16).slice(2)}@shop.test`) {
    await call('POST', '/users/register', { body: { email, password: 'password123' } });
    return login(email, 'password123');
  }

  const firstProduct = async (name) => {
    const r = await call('GET', '/products');
    return r.body.items.find((p) => !name || p.name === name);
  };

  return { call, raw, login, registerAndLogin, firstProduct, close: () => server.close() };
}
